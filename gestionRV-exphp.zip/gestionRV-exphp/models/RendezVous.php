<?php
class RendezVous {
    public int $id;
    public int $patientId;
    public int $medecinId;
    public string $specialite;
    public string $dateHeure;
    public string $status;

    public static function toRendezVous(array $row): RendezVous {
        $rv = new RendezVous();
        $rv->id = $row['id'];
        $rv->patientId = $row['patient_id'];
        $rv->medecinId = $row['medecin_id'];
        $rv->specialite = $row['specialite'];
        $rv->dateHeure = $row['date_heure'];
        $rv->status = $row['status'];
        return $rv;
    }
}
?>