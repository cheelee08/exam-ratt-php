<?php
require_once "./config/Database.php";
require_once "./models/RendezVous.php";

class RendezVousRepository {

    private Database $database;

    public function __construct() {
        $this->database = new Database();
    }

    public function selectAllRendezVous(): array {
        $sql = "SELECT * FROM rendez_vous";
        try {
            $stmt = $this->database->getPdo()->query($sql);
            $rendezvous = [];
            while ($row = $stmt->fetch()) {
                $rendezvous[] = RendezVous::toRendezVous($row);
            }
            return $rendezvous;
        } catch (PDOException $ex) {
            echo "Erreur : " . $ex->getMessage();
            exit;
        }
    }

    public function selectRendezVousByPatientId(int $patientId): array {
        $sql = "SELECT * FROM rendez_vous WHERE patient_id = $patientId";
        try {
            $stmt = $this->database->getPdo()->query($sql);
            $rendezvous = [];
            while ($row = $stmt->fetch()) {
                $rendezvous[] = RendezVous::toRendezVous($row);
            }
            return $rendezvous;
        } catch (PDOException $ex) {
            echo "Erreur : " . $ex->getMessage();
            exit;
        }
    }

    public function selectRendezVousById(int $id): RendezVous|null {
        $sql = "SELECT * FROM rendez_vous WHERE id = $id";
        try {
            $stmt = $this->database->getPdo()->query($sql);
            $row = $stmt->fetch();
            return $row ? RendezVous::toRendezVous($row) : null;
        } catch (PDOException $ex) {
            echo "Erreur : " . $ex->getMessage();
            exit;
        }
        return null;
    }

    public function insertRendezVous(RendezVous $rv): int {
        $sql = "INSERT INTO rendez_vous (patient_id, medecin_id, specialite, date_heure, status)
                VALUES ('{$rv->patientId}', '{$rv->medecinId}', '{$rv->specialite}', '{$rv->dateHeure}', 'EN_ATTENTE')";
        try {
            return $this->database->getPdo()->exec($sql);
        } catch (PDOException $ex) {
            echo "Erreur : " . $ex->getMessage();
            exit;
        }
    }

    public function annulerRendezVous(int $id): bool {
        $sql = "SELECT date_heure FROM rendez_vous WHERE id = $id";
        try {
            $stmt = $this->database->getPdo()->query($sql);
            $row = $stmt->fetch();

            if (!$row) return false;

            $dateRV = new DateTime($row['date_heure']);
            $now = new DateTime();
            $interval = $now->diff($dateRV);

            if ($dateRV > $now && $interval->days >= 2) {
                $sql = "UPDATE rendez_vous SET status = 'ANNULE' WHERE id = $id";
                $this->database->getPdo()->exec($sql);
                return true;
            }
        } catch (PDOException $ex) {
            echo "Erreur : " . $ex->getMessage();
            exit;
        }
        return false;
    }
}
?>