<!DOCTYPE html>
<html>
<head>
    <title>Gestion des Rendez-vous</title>
</head>
<body>
    <h1>Bienvenue à la Clinique</h1>
    <ul>
        <li><a href="patient_rv.php">Voir les rendez-vous</a></li>
    </ul>
</body>
</html>