<?php
require_once "../repositories/RendezVousRepository.php";

$repo = new RendezVousRepository();
$patientId = 1; // Simulation d’un patient connecté

$rvs = $repo->getRendezVousByPatient($patientId);
?>
<h2>Mes rendez-vous</h2>
<table border="1">
    <tr><th>Date</th><th>Spécialité</th><th>Statut</th></tr>
    <?php foreach($rvs as $rv): ?>
    <tr>
        <td><?= $rv->dateHeure ?></td>
        <td><?= $rv->specialite ?></td>
        <td><?= $rv->status ?></td>
    </tr>
    <?php endforeach; ?>
</table>